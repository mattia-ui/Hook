//
//  Scarpe.swift
//  deeplab-ios
//
//  Created by Antonio Cimino on 01/03/2020.
//  Copyright © 2020 xyh. All rights reserved.
//

import UIKit

class Outfit: UICollectionViewCell {
    @IBOutlet weak var m: UIImageView!
    @IBOutlet weak var p: UIImageView!
    @IBOutlet weak var s: UIImageView!
}
