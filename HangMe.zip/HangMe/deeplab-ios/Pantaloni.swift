//
//  Pantaloni.swift
//  deeplab-ios
//
//  Created by Antonio Cimino on 01/03/2020.
//  Copyright © 2020 xyh. All rights reserved.
//

import UIKit

class Pantaloni: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
}
